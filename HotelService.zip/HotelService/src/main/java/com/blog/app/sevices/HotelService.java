package com.blog.app.sevices;

import java.util.List;

import com.blog.app.entities.Hotel;

public interface HotelService {

	// post
	Hotel createHotel(Hotel hotel);

	// get using id
	Hotel getHotel(String hotelId);

	// get all data
	List<Hotel> getHotels();

}
