package com.blog.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

//This is the key annotation of application.It is the staring point of main application.
@SpringBootApplication
public class UserService{


	public static void main(String[] args) {
		SpringApplication.run(UserService.class, args);
	}
}

