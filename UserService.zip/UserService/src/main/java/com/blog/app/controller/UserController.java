package com.blog.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.blog.app.entities.User;
import com.blog.app.playloads.ApiResponse;
import com.blog.app.sevices.UserService;

@RestController
@RequestMapping("/api/users/")
public class UserController {

	@Autowired
	private UserService userService;

	// post
	@PostMapping("/")
	public ResponseEntity<User> creatUser(@RequestBody User user) {

		User createUser = userService.createUser(user);
		return new ResponseEntity<User>(createUser, HttpStatus.OK);
	}

	// get by id
	@GetMapping("/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable String userId) {
		User userById = userService.getUserById(userId);
		return new ResponseEntity<User>(userById, HttpStatus.OK);
	}

	// get all users
	@GetMapping("/")
	public ResponseEntity<List<User>> getAllUsers() {
		List<User> users = userService.getAllUsers();
		return new ResponseEntity<List<User>>(users, HttpStatus.OK);
	}


}
