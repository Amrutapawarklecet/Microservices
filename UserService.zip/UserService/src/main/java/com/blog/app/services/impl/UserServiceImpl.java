package com.blog.app.services.impl;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.app.entities.User;
import com.blog.app.exceptions.ResourceNotFoundExpection;
import com.blog.app.repositories.UserRepo;
import com.blog.app.sevices.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo userRepo;

	@Override
	public User createUser(User user) {

		// generate unique id
		String randomUserId = UUID.randomUUID().toString();
		user.setUserId(randomUserId);
		User createUser = userRepo.save(user);
		return createUser;
	}


	@Override
	public User getUserById(String userId) {
		User getUser = userRepo.findById(userId).orElseThrow(() -> new ResourceNotFoundExpection("User", "id", userId));
		return getUser;
	}

	@Override
	public List<User> getAllUsers() {
		List<User> findAllUsers = userRepo.findAll();
		return findAllUsers;
	}


}
