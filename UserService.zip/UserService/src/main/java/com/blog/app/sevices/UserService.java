package com.blog.app.sevices;

import java.util.List;

import com.blog.app.entities.User;

public interface UserService {

	// post
	User createUser(User user);

	// get using id
	User getUserById(String userId);
	
	// get all data
	List<User> getAllUsers();
	

}
